# ds_Harsh_Rajput

This repository contains the full data science assignment for Web3 Trading Team.

## Structure
- notebook_1.ipynb
- csv_files/
- outputs/
- ds_report.pdf
